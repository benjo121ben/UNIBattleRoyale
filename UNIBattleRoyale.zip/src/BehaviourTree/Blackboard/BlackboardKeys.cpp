//
// Created by benja on 19/01/2022.
//

#include "BlackboardKeys.h"

std::string BlackboardKeys::PLAYERID(){return "PLAYERID";}

std::string BlackboardKeys::PLAYERMOVEDIR(){return "PLAYERMOVEDIR";}

std::string BlackboardKeys::ATTACKTARGETID() { return "ATTACKTARGETID";}
