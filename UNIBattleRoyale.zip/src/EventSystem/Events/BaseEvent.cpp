//
// Created by benja on 18/01/2022.
//
#include "BaseEvent.h"



std::string BaseEvent::getEventType() const{
    return eventType;
}
std::string BaseEvent::getEventText() const{
    return eventText;
}
