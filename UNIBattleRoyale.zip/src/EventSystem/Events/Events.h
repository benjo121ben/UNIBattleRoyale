//
// Created by benja on 18/01/2022.
//

#ifndef GAME_EVENTS_H
#define GAME_EVENTS_H
#include "BaseEvent.h"
#include "KillEvent.h"
#include "MoveEvent.h"
#endif //GAME_EVENTS_H
